# tookilig PWA (Option 2: External Manifest Hosting)

This bundle includes:
- `manifest.json`
- `icons/` (192px, 512px, maskable 512px)

## How to host on GitHub Pages
1) Create a new GitHub repo (public). Name doesn't matter (e.g., `tookilig-pwa`).
2) Upload **manifest.json** and the **icons/** folder to the repo root.
3) In the repo: Settings → Pages → Build and deployment → Source = `Deploy from a branch`, Branch = `main` (root). Save.
4) After a minute, you'll get a Pages URL, e.g. `https://<username>.github.io/tookilig-pwa/manifest.json`.
5) Copy that manifest URL.

## How to link in Odoo (HTML Head)
In your website backend: Website → Configuration → Settings → (HTML Head / Edit Head) add:

<link rel="manifest" href="https://<username>.github.io/tookilig-pwa/manifest.json">
<link rel="apple-touch-icon" href="https://<username>.github.io/tookilig-pwa/icons/icon-192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="theme-color" content="#16a34a">

Replace `<username>` with your GitHub username.

### Notes
- Android will accept a cross-origin manifest, but full **install prompts** and **offline** require a Service Worker **on your domain**. If your Odoo plan doesn't let you place `/sw.js` on `tookilig.com`, users can still **Add to Home Screen** (Android menu or iOS Share → Add to Home Screen). 
- For full PWA (offline + prompts) or store publishing, use a thin wrapper (Capacitor) or enable a service worker on `tookilig.com`.
